#ifndef _KERNEL_KPRINTF_H_
#define _KERNEL_KPRINTF_H_

#include <sys/types.h>

void kprintf( char *, ... );

#endif
