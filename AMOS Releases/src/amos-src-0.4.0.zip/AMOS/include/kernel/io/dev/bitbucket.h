#ifndef _KERNEL_IO_DEV_BITBUCKET_H_
#define _KERNEL_IO_DEV_BITBUCKET_H_

int bitbucket_init();

#endif
