#include <kernel/kernel.h>
#include <kernel/console.h>

static BYTE * console_mem;

int console_x, console_y;

BYTE console_attrib;

void kprintf( char * text, ... )
{
	int i, j;
	BYTE * string;
	va_list args;

	va_start( args, text );

	i = 0;

	while( text[i] )
	{
		if( text[i] == '%' )
		{
			i++;

			switch( text[i] )
			{
				case 's':
					string = va_arg( args, BYTE * );
					j = 0;
					while( string[j] ) 
						console_putch( string[j++] );
					break;
				case 'c':
					console_putch( va_arg( args, BYTE ) );
					break;
				default:
					console_putch( text[i] );
			}

			i++;

		} else {
			console_putch( text[i] );
			i++;
		}

	}

	va_end( args );
}

void console_putch( BYTE c )
{
	switch( c )
	{
		case '\n':
			console_setcursor( 0, ++console_y );
			break;
		case '\r':
			console_setcursor( 0, console_y );
			break;
		case '\t':
			console_putch( ' ' );
			console_putch( ' ' );
			console_putch( ' ' );
			console_putch( ' ' );
			break;
		case '\a':
			console_beep();
			break;
		case '\f':
			console_cls();
			console_setcursor( 0, 0 );
			break;
		default:
			console_putchar( console_x, console_y, c, console_attrib );
			console_setcursor( ++console_x, console_y );
			break;
	}


	if( console_x > CONSOLE_COLUMNS-1 )
		console_setcursor( 0, ++console_y );

	if( console_y > CONSOLE_ROWS-1 )
	{
		console_scrollup();
		console_setcursor( console_x, CONSOLE_ROWS-1 );
	}
}

void console_putchar( int x, int y, BYTE c, BYTE attrib )
{
    console_mem[ (x + (y*CONSOLE_COLUMNS)) * 2 ] = c;
    console_mem[ ((x + (y*CONSOLE_COLUMNS)) * 2) + 1 ] = attrib;
}

BYTE console_getchar( int x, int y )
{
    return console_mem[ (x + (y*CONSOLE_COLUMNS)) * 2 ];
}

void console_setattrib( BYTE attrib )
{
    console_attrib = attrib;
}

BYTE console_getattrib( int x, int y )
{
    return console_mem[ ((x + (y*CONSOLE_COLUMNS)) * 2) + 1 ];
}

void console_scrollup( void )
{
	int i, j;

    for( j=1 ; j<CONSOLE_ROWS-1; j++ )
    {
		for( i=0; i<CONSOLE_COLUMNS ; i++ )
			console_putchar( i, j, console_getchar( i, j+1 ), console_getattrib( i, j+1 ) );
    }

    for( i=0 ; i<CONSOLE_COLUMNS ; i++ )
		console_putchar( i, CONSOLE_ROWS-1, ' ', console_attrib );
}

void console_setcursor( int x, int y )
{
    short index = (y * CONSOLE_COLUMNS) + x;
    
	console_x = x;
    console_y = y;

	outportb( 0x3D4, 14 );
    outportb( 0x3D5, index >> 8 );
    outportb( 0x3D4, 15 );
    outportb( 0x3D5, index );
}

void console_cls( void )
{
	int i, j;

    for( i=0 ; i<CONSOLE_COLUMNS ; i++ )
    {
		for( j=0 ; j<CONSOLE_ROWS ; j++ )
			console_putchar( i, j, ' ', console_attrib );
    }
}

void console_beep( void )
{

}

void console_init( void )
{
    console_mem = (BYTE *)VIDEOMEM_BASE;

    console_setattrib( GREEN | RED_BG );

    console_cls();

    console_setcursor( 0, 0 );
}

