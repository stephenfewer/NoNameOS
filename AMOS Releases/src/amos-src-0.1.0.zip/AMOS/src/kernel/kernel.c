#include <kernel/kernel.h>
#include <kernel/console.h>
#include <kernel/gdt.h>
#include <kernel/idt.h>
#include <kernel/irq.h>

BYTE * memset( BYTE * dest, BYTE val, int count )
{
    BYTE * temp = dest;
    for( ; count !=0 ; count-- ) *temp++ = val;
    return dest;
}

BYTE inportb( WORD port )
{
    BYTE rv;
    __asm__ __volatile__ ( "inb %1, %0" : "=a" (rv) : "dN" (port) );
    return rv;
}

void outportb( WORD port, BYTE data )
{
    __asm__ __volatile__ ( "outb %1, %0" : : "dN" (port), "a" (data) );
}

int main( struct MULTIBOOT_INFO * m )
{
	console_init();

    kprintf( "AMOS %s\n", KERNEL_VERSION );

	gdt_init();

	idt_init();

	irq_init();

	sti();

	//__asm__ __volatile__("int %0" : : "i"(16));

    for(;;);

	return 0;
}

