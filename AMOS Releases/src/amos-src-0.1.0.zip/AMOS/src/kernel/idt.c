#include <kernel/idt.h>
#include <kernel/kernel.h>
#include <kernel/isr.h>

struct IDT_ENTRY   idt_table[IDT_ENTRYS];

struct IDT_POINTER idt_pointer;

ISR isr_stubs[] =
{
    isr00, isr01, isr02, isr03, isr04, isr05, isr06, isr07, 
	isr08, isr09, isr10, isr11, isr12, isr13, isr14, isr15,
	isr16, isr17, isr18, isr19, isr20, isr21, isr22, isr23,
	isr24, isr25, isr26, isr27, isr28, isr29, isr30, isr31
};

void idt_setentry( BYTE i, ISR isr_routine, WORD selector, BYTE flags )
{
	idt_table[i].base_high = ((DWORD)isr_routine & 0xFFFF0000) >> 16;

	idt_table[i].base_low  = ((DWORD)isr_routine & 0xFFFF);

	idt_table[i].flags = flags;

	idt_table[i].reserved = 0;

	idt_table[i].selector = selector;
}

void idt_init()
{
	int i;

    idt_pointer.limit = ( sizeof(struct IDT_ENTRY) * IDT_ENTRYS ) - 1;
    idt_pointer.base = (unsigned int)&idt_table;

    memset( (BYTE *)&idt_table, 0, sizeof(struct IDT_ENTRY) * IDT_ENTRYS );

	for( i=0 ; i<32 ; i++ )
	{
		idt_setentry(  i, isr_stubs[i], 0x08, 0x8E );
		isr_sethandler( i, NULL );
	}

	__asm__( "lidt (%0)" : : "r" ( &idt_pointer) );
}

